from langchain_community.chat_models import AzureChatOpenAI


class LLMManager:
    def __init__(self):
        self.api_key = "6ffhCm6wvgxD2LRD7wNZI5sHgqHn4lqYOY7xn8Ycdg7vHvZ8qyujJQQJ99BCACYeBjFXJ3w3AAABACOGwuFA"
        self.api_version = "2023-07-01-preview"
        self.azure_deployment = "gpt-4o"
        self.azure_endpoint = "https://tcoeaiteamgpt4o.openai.azure.com/"

    def get_llm(self):
        return AzureChatOpenAI(
            openai_api_key=self.api_key,
            openai_api_version=self.api_version,
            azure_deployment=self.azure_deployment,
            azure_endpoint=self.azure_endpoint,
        )
