# import os
# import logging
# import pandas as pd
# import uuid  # For generating unique IDs
# from<span style="background-color:#F4A593"> arize_otel </span>import<span style="background-color:#F4A593"> register_otel, Endpoints</span>
# from langchain_core.output_parsers import StrOutputParser
# from langchain_core.prompts import ChatPromptTemplate
# from<span style="background-color:#F4A593"> openinference.instrumentation.langchain </span>import<span style="background-color:#F4A593"> LangChainInstrumentor</span>
# from<span style="background-color:#F4A593"> arize.api </span>import<span style="background-color:#F4A593"> Client</span>
# from arize.utils.types import ModelTypes, Environments, Embedding
# from langchain_openai import AzureChatOpenAI
# from langchain.document_loaders import PyPDFLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from sentence_transformers import SentenceTransformer
# from sklearn.metrics.pairwise import cosine_similarity
# from<span style="background-color:#F4A593"> openinference.semconv.trace </span>import<span style="background-color:#F4A593"> SpanAttributes</span>
# from<span style="background-color:#F4A593"> opentelemetry </span>import<span style="background-color:#F4A593"> trace</span>

# # Set up logging for detailed output
# logging.basicConfig(level=logging.DEBUG)


# # Function to initialize the model based on user choice
# def initialize_model(model_choice):
#     if model_choice == 'gpt-3.5':
#         os.environ["OPENAI_API_KEY"] = "0b1d7d099829418fb1293b97f2ae9c23"
#         os.environ["OPENAI_API_VERSION"] = "2023-03-15-preview"
#         deployment_name = "gpt35exploration"
#         azure_endpoint = "https://exploregenaiworkspace.openai.azure.com"
#     elif model_choice == 'gpt-4':
#         os.environ["OPENAI_API_KEY"] = "DH8RAnW9UnbzuSxm8luI7Go8nX42bdLhFIEKcPQ1U0JpOU0hPeLKJQQJ99BAACYeBjFXJ3w3AAABACOGdstk"
#         os.environ["OPENAI_API_VERSION"] = "2024-05-01-preview"
#         deployment_name = "gpt-4o"
#         azure_endpoint = "https://tcoeaiteamgpt4o.openai.azure.com/"
#     else:
#         raise ValueError("Invalid model choice. Choose 'gpt-3.5' or 'gpt-4'.")

#     # Initialize the chosen model
#     return AzureChatOpenAI(
#         deployment_name=deployment_name,
#         azure_endpoint=azure_endpoint,
#         temperature=0.0
#     )


# # User selects model version
# model_choice = input("Select the model version (gpt-3.5/gpt-4): ").strip().lower()
# try:
#     chat_model = initialize_model(model_choice)
# except ValueError as e:
#     print(e)
#     exit()

# # Continue with the rest of the setup as before
# # Register OpenTelemetry
# <span style="background-color:#F4A593">register_otel(</span>
# <span style="background-color:#F4A593">    endpoints=Endpoints.ARIZE,</span>
# <span style="background-color:#F4A593">    space_key=</span>"091b0b9"<span style="background-color:#F4A593">,</span>
# <span style="background-color:#F4A593">    api_key=</span>"7b6cbce7345fa137c18"<span style="background-color:#F4A593">,</span>
# <span style="background-color:#F4A593">    model_id=</span>f"arize-testing-{model_choice}"<span style="background-color:#F4A593">,</span>
# <span style="background-color:#F4A593">)</span>

# <span style="background-color:#F4A593">LangChainInstrumentor().instrument()</span>

# # Load a free transformer model for embeddings
# model = SentenceTransformer('all-MiniLM-L6-v2')

# # Initialize Arize client with proper Space ID and API key
# arize_client = Client(space_id='U3BhY2U6OTEzMDorSUlR', api_key='7b6cbce7345fa137c18')

# # Define the prompt template
# prompt = ChatPromptTemplate.from_messages([
#     ("system",
#      "You are an intelligent assistant designed to provide accurate and helpful answers to user questions. Address "
#      "the user's query using the context provided."),
#     ("user", "{context}\n\nUser Question: {input}")
# ])

# output_parser = StrOutputParser()

# # Create the chain for the task
# chain = prompt | chat_model | output_parser

# # Get tracer for OpenTelemetry
# <span style="background-color:#F4A593">tracer = trace.get_tracer(__name__)</span>

# # Generate a unique user_id when the session starts
# user_id = str(uuid.uuid4())
# print(f"New session started for user_id: {user_id}")


# # Document upload and chunking
# def upload_and_chunk_document(file_path):
#     loader = PyPDFLoader(file_path)
#     documents = loader.load()
#     text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
#     chunks = text_splitter.split_documents(documents)
#     return chunks


# # Generate embeddings for the document chunks
# def generate_chunk_embeddings(chunks):
#     chunk_texts = [chunk.page_content for chunk in chunks]
#     embeddings = model.encode(chunk_texts, convert_to_tensor=True)
#     return chunk_texts, embeddings


# # Load and process the document
# file_path = r"C:\Users\SRDTPLFST\Downloads\python-and-java.pdf"
# chunks = upload_and_chunk_document(file_path)
# chunk_texts, chunk_embeddings = generate_chunk_embeddings(chunks)

# while True:
#     # Generate a new session_id for each interaction
#     session_id = str(uuid.uuid4())
#     print(f"New session_id for this interaction: {session_id}")

#     user_input = input("You: ")
#     if user_input.lower() in ["exit", "quit"]:
#         print(f"Session ended for user_id: {user_id}")
#         print("Exiting the chat. Goodbye!")
#         break

#     user_embedding = model.encode([user_input], convert_to_tensor=True)[0]

#     # Calculate similarities between user input and chunk embeddings
#     similarities = cosine_similarity([user_embedding], chunk_embeddings)
#     top_k_indices = similarities[0].argsort()[-2:][::-1]  # Get indices of top 2 similar chunks

#     relevant_chunks = [chunk_texts[i] for i in top_k_indices]
#     similarity_scores = similarities[0][top_k_indices]

#     print("Relevant Chunks Used for Context:")
#     for i, chunk in enumerate(relevant_chunks):
#         print(f"Chunk {i + 1}: {chunk}")

#     if all(similarity < 0.3 for similarity in similarity_scores):
#         print("Bot: I do not have enough relevant context to answer this question.")
#         continue

#     context_input = ' '.join(relevant_chunks)

#     <span style="background-color:#F4A593">model_input = {</span>
# <span style="background-color:#F4A593">        </span>"input"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"value"<span style="background-color:#F4A593">: user_input</span>
# <span style="background-color:#F4A593">        },</span>
# <span style="background-color:#F4A593">        </span>"context"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"value"<span style="background-color:#F4A593">: context_input</span>
# <span style="background-color:#F4A593">        },</span>
# <span style="background-color:#F4A593">        </span>"openinference"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"span"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">                </span>"kind"<span style="background-color:#F4A593">: </span>"CHAIN"
# <span style="background-color:#F4A593">            }</span>
# <span style="background-color:#F4A593">        }</span>
#     <span style="background-color:#F4A593">}</span>
# <span style="background-color:#F4A593">    </span># Manual Instrumentation
# <span style="background-color:#F4A593">    </span># Start trace span for current operation
# <span style="background-color:#F4A593">    </span>with<span style="background-color:#F4A593"> tracer.start_as_current_span(</span>f"arize-trace-span"<span style="background-color:#F4A593">) </span>as<span style="background-color:#F4A593"> span:</span>
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.OPENINFERENCE_SPAN_KIND, </span>"CHAIN"<span style="background-color:#F4A593">)</span>

# <span style="background-color:#F4A593">        </span># Session id
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.SESSION_ID, session_id)</span>

# <span style="background-color:#F4A593">        </span># User id
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.USER_ID, user_id)</span>

# <span style="background-color:#F4A593">        </span># Input span
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.INPUT_VALUE, user_input)</span>
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.INPUT_MIME_TYPE, </span>"text/plain"<span style="background-color:#F4A593">)</span>

# <span style="background-color:#F4A593">        </span># Context span
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.CONTEXT_VALUE, context_input)</span>
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.CONTEXT_MIME_TYPE, </span>"text/plain"<span style="background-color:#F4A593">)</span>

# <span style="background-color:#F4A593">        </span># Output span
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.OUTPUT_MIME_TYPE, </span>"text/plain"<span style="background-color:#F4A593">)</span>
# <span style="background-color:#F4A593">        span.set_attribute(SpanAttributes.TAG_TAGS, </span>"['user-query', 'arize-log']"<span style="background-color:#F4A593">)</span>

# <span style="background-color:#F4A593">        </span>try<span style="background-color:#F4A593">:</span>
# <span style="background-color:#F4A593">            </span># Get the answer from the chain
# <span style="background-color:#F4A593">            answer = chain.invoke(model_input)</span>

# <span style="background-color:#F4A593">            </span># Set the span status to OK if everything succeeded
# <span style="background-color:#F4A593">            span.set_status(trace.Status(trace.StatusCode.OK))</span>
# <span style="background-color:#F4A593">            span.set_attribute(SpanAttributes.OUTPUT_VALUE, answer)</span>

# <span style="background-color:#F4A593">        </span>except<span style="background-color:#F4A593"> Exception </span>as<span style="background-color:#F4A593"> e:</span>
# <span style="background-color:#F4A593">            </span># Set the span status to ERROR if something went wrong
# <span style="background-color:#F4A593">            span.set_status(trace.Status(trace.StatusCode.ERROR, description=</span>str<span style="background-color:#F4A593">(e)))</span>
# <span style="background-color:#F4A593">            </span>raise<span style="background-color:#F4A593"> e</span>

# <span style="background-color:#F4A593">    final_output = {</span>
# <span style="background-color:#F4A593">        </span>"user_id"<span style="background-color:#F4A593">: user_id,</span>
# <span style="background-color:#F4A593">        </span>"session_id"<span style="background-color:#F4A593">: session_id,</span>
# <span style="background-color:#F4A593">        </span>"input"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"value"<span style="background-color:#F4A593">: user_input</span>
# <span style="background-color:#F4A593">        },</span>
# <span style="background-color:#F4A593">        </span>"context"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"value"<span style="background-color:#F4A593">: context_input</span>
# <span style="background-color:#F4A593">        },</span>
# <span style="background-color:#F4A593">        </span>"openinference"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"span"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">                </span>"kind"<span style="background-color:#F4A593">: </span>"CHAIN"
# <span style="background-color:#F4A593">            }</span>
# <span style="background-color:#F4A593">        },</span>
# <span style="background-color:#F4A593">        </span>"output"<span style="background-color:#F4A593">: {</span>
# <span style="background-color:#F4A593">            </span>"value"<span style="background-color:#F4A593">: answer</span>
# <span style="background-color:#F4A593">        }</span>
# <span style="background-color:#F4A593">    }</span>

# <span style="background-color:#F4A593">    </span>print<span style="background-color:#F4A593">(</span>"Final Output JSON:"<span style="background-color:#F4A593">)</span>
# <span style="background-color:#F4A593">    </span>print<span style="background-color:#F4A593">(final_output)</span>

#     answer_with_context = f"{answer}\n\n[Based on the following context: {' | '.join(relevant_chunks)}]"
#     print(f"Bot: {answer_with_context}")

#     # Check for grounded keywords
#     keywords = set(" ".join(relevant_chunks).split())
#     response_words = set(answer.split())
#     common_words = keywords.intersection(response_words)

#     if common_words:
#         print(f"The response is grounded in the context with common words: {common_words}")
#     else:
#         print("The response may not be grounded in the provided context.")

#     answer_embedding = model.encode([answer], convert_to_tensor=True)[0]

#     prompt_embedding = Embedding(vector=user_embedding.tolist(), data=user_input)
#     response_embedding = Embedding(vector=answer_embedding.tolist(), data=answer)

#     try<span style="background-color:#F4A593">:</span>
# <span style="background-color:#F4A593">        response = arize_client.log(</span>
# <span style="background-color:#F4A593">            model_id=</span>'arize-testing-3.5'<span style="background-color:#F4A593">,</span>
# <span style="background-color:#F4A593">            model_version=</span>'v2'<span style="background-color:#F4A593">,</span>
# <span style="background-color:#F4A593">            model_type=ModelTypes.GENERATIVE_LLM,</span>
# <span style="background-color:#F4A593">            environment=Environments.PRODUCTION,</span>
# <span style="background-color:#F4A593">            prompt=prompt_embedding,</span>
# <span style="background-color:#F4A593">            response=response_embedding,</span>

# <span style="background-color:#F4A593">        )</span>
# <span style="background-color:#F4A593">        </span>print<span style="background-color:#F4A593">(</span>f"Arize Log Response: {response}"<span style="background-color:#F4A593">)</span>
# <span style="background-color:#F4A593">        </span>print<span style="background-color:#F4A593">(</span>"User input and response embeddings have been logged to Arize successfully."<span style="background-color:#F4A593">)</span>
# <span style="background-color:#F4A593">    </span>except<span style="background-color:#F4A593"> Exception </span>as<span style="background-color:#F4A593"> e:</span>
# <span style="background-color:#F4A593">        </span>print<span style="background-color:#F4A593">(</span>f"Failed to log data to Arize: {e}"<span style="background-color:#F4A593">)</span>
