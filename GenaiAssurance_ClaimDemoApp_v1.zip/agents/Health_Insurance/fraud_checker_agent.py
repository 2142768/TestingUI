from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import Runnable, RunnableLambda
from langchain_core.messages import HumanMessage
import json
import os
from dotenv import load_dotenv

# Assuming these imports exist in your project setup
from configuration.logger import log_trace
from configuration.state import GraphState  # Assuming GraphState is defined here

load_dotenv()

# Assuming llm is initialized globally or passed down appropriately in your main application
# Example:
# from langchain_openai import AzureChatOpenAI
# llm = AzureChatOpenAI(
#     openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
#     azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
#     azure_endpoint=os.getenv("AZURE_OPENAI_API_BASE"),
#     api_key=os.getenv("AZURE_OPENAI_API_KEY"),
# )


def fraud_duplicate_claim_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()  # Access state as a dictionary
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get(
            "notes", []
        )  # Access notes from claim_record
        claim_record = state_data.get("claim_record", {})

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - duplicate_claim_review" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No duplicate claim detected."

        if matching_note:
            reason = matching_note
            # If a specific note exists, assume no fraud from LLM here for demonstration
            # In a real scenario, the note might indicate fraud. Adjust as needed.
        else:
            prompt = f"""
You are an AI assistant tasked with validating an insurance claim for fraud detection, specifically for Health Insurance.

Rule: 'duplicate_claim_review'

Your task is to:
- Determine whether identical or overlapping claims for the same service, or from the same time period for the same patient, have been previously submitted.
- Analyze the provided 'Claim Record' for any indicators of duplication.

Claim Record:
{json.dumps(claim_record, indent=2)}

Based on this information, assess the likelihood of a duplicate claim and assign a fraud score from 0 to 100.
- If definitely not a duplicate: Score 0.
- If suspicious but not confirmed (e.g., similar details but different dates/amounts, or overlapping but not identical services): Score between 30 and 70.
- If highly likely a duplicate: Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "not_duplicate" or "suspicious" or "duplicate",
  "reason": "<brief explanation for the status>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
Do not ask for more data.
"""
            try:
                response = llm.invoke([HumanMessage(content=prompt)])

                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Unclear duplicate claim status.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "not_duplicate":
                    fraud_score = 0.0  # Force 0 if LLM explicitly says not duplicate
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:  # 0 < fraud_score <= 30
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0  # High fraud score if parsing fails
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),  # Use datetime.now() for local time if preferred
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: duplicate_claim_review)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }
        log_trace(
            claim_id=state_data.get(
                "policy_id", "UNKNOWN"
            ),  # Using policy_id for log trace claim_id if available
            step="fraud_checker_agent.duplicate_claim_review",
            output=output,
        )
        # Update the state with the result, score, and review flag
        return {
            "duplicate_claim_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_inconsistency_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        document_text = state_data.get(
            "document_text", ""
        )  # Assuming document_text contains relevant docs

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - inconsistency_detection" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "No inconsistencies detected."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
You are an AI assistant validating a health insurance claim under the 'inconsistency_detection' rule.

Task: Check for inconsistencies between submitted documents and claim details (e.g., mismatched dates of service, different amounts billed vs. approved, conflicting diagnoses, or discrepancies with medical history).

Claim Record:
{json.dumps(claim_record, indent=2)}
Relevant Document Text:
{document_text}

Based on this information, assess the presence of inconsistencies and assign a fraud score from 0 to 100.
- If no inconsistencies found: Score 0.
- If minor inconsistencies (e.g., slight date variations, small amount discrepancies): Score between 30 and 70.
- If major inconsistencies (e.g., conflicting diagnoses, services claimed not matching medical records, significant billing discrepancies): Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "consistent" or "inconsistent" or "minor_inconsistencies",
  "reason": "<brief explanation for the consistency/inconsistency>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume minor inconsistencies and assign a score between 30-40.
Do not ask for more data.
"""
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "minor_inconsistencies")
                reason = parsed.get("reason", "Could not verify consistency.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "consistent":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: inconsistency_detection)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }
        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.inconsistency_detection",
            output=output,
        )
        return {
            "inconsistency_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_provider_verification_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        # Assuming provider details are part of claim_record or document_text
        provider_details = claim_record.get("provider_details", "N/A")
        document_text = state_data.get("document_text", "")

        matching_note = next(
            (n for n in notes if "fraud_checker_agent - provider_verification" in n),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "Provider verified."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
You are an AI assistant validating a health insurance claim under the 'provider_verification' rule.

Your task is to:
- Determine if the listed healthcare provider (hospital, doctor, clinic, etc.) exists and is legitimate.
- Look for any signs that the provider information might be fabricated or suspicious.
- Utilize the 'Claim Record' and any 'Document Text' to verify provider details.

Claim Record:
{json.dumps(claim_record, indent=2)}
Provider Details (from claim record): {provider_details}
Relevant Document Text:
{document_text}

Based on this information, assess the legitimacy of the provider and assign a fraud score from 0 to 100.
- If provider is clearly legitimate/verified: Score 0.
- If suspicious but not confirmed (e.g., vague provider info, hard to cross-reference, new/unfamiliar provider): Score between 30 and 70.
- If the provider seems highly fabricated or linked to known fraud: Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "verified" or "suspicious" or "fabricated",
  "reason": "<brief explanation>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
Do not ask for more data.
"""
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Provider identity unclear.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "verified":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: provider_verification)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }
        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.provider_verification",
            output=output,
        )
        return {
            "provider_verification_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


def fraud_service_reasonability_checker(llm) -> Runnable:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()
        claim_id = state_data.get("claim_id", f"CLM_{state_data.get('policy_id', '')}")
        notes = state_data.get("claim_record", {}).get("notes", [])
        claim_record = state_data.get("claim_record", {})
        # Assuming medical condition and services claimed are part of claim_record or document_text
        medical_condition = claim_record.get("medical_condition", "N/A")
        services_claimed = claim_record.get("services_claimed", "N/A")
        document_text = state_data.get("document_text", "")

        matching_note = next(
            (
                n
                for n in notes
                if "fraud_checker_agent - service_reasonability_check" in n
            ),
            None,
        )

        fraud_score = 0.0
        human_review = False
        status = "passed"
        reason = "Claimed services are medically reasonable."

        if matching_note:
            reason = matching_note
        else:
            prompt = f"""
You are an AI assistant reviewing a health insurance claim for the 'service_reasonability_check' rule.

Task: Evaluate if the claimed services are medically reasonable and necessary given the policyholder’s reported condition, medical history (if available), and other supporting documents. Look for over-utilization, unbundled services, or services unrelated to the diagnosis.

Claim Record:
{json.dumps(claim_record, indent=2)}
Policyholder's Medical Condition: {medical_condition}
Services Claimed: {services_claimed}
Relevant Document Text:
{document_text}

Based on this information, assess the medical reasonability of the services and assign a fraud score from 0 to 100.
- If services are clearly medically reasonable and necessary: Score 0.
- If services are somewhat suspicious (e.g., higher frequency than typical, slightly unusual combination of services for condition): Score between 30 and 70.
- If services appear highly unreasonable, unnecessary, or abusive (e.g., excessive billing, services not justified by diagnosis): Score above 70.

Respond strictly in the following JSON format:
{{
  "status": "reasonable" or "suspicious" or "unreasonable",
  "reason": "<brief explanation>",
  "fraud_score": <integer score between 0 and 100>
}}
If data is too sparse to decide definitively, assume suspicious and assign a score between 30-40.
Do not ask for more data.
"""
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                response_content = (
                    response.content.strip().replace("```json", "").replace("```", "")
                )
                parsed = json.loads(response_content)
                status_llm = parsed.get("status", "suspicious")
                reason = parsed.get("reason", "Service reasonability unclear.")
                fraud_score = float(parsed.get("fraud_score", 35.0))

                if status_llm == "reasonable":
                    fraud_score = 0.0
                elif fraud_score > 70:
                    status = "failed"
                elif 30 < fraud_score <= 70:
                    human_review = True
                    status = "manual_review"
                else:
                    status = "passed_with_minor_flags"
                    human_review = False

            except Exception as e:
                status = "failed"
                reason = f"LLM response could not be parsed: {e}"
                fraud_score = 75.0
                human_review = False

        output = {
            "timestamp": datetime.now().isoformat(),
            "claim_id": claim_id,
            "step": "fraud_checker_agent (Rule: service_reasonability_check)",
            "status": status,
            "reason": reason,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }
        log_trace(
            claim_id=state_data.get("policy_id", "UNKNOWN"),
            step="fraud_checker_agent.service_reasonability_check",
            output=output,
        )
        return {
            "service_reasonability_check_result": output,
            "fraud_score": fraud_score,
            "human_review_required": human_review,
        }

    return RunnableLambda(run)


# Helper function to get all health fraud checker agents
def get_health_fraud_checker_agents(llm):
    return {
        "duplicate_claim": fraud_duplicate_claim_checker(llm),
        "inconsistency_detection": fraud_inconsistency_checker(llm),
        "provider_verification": fraud_provider_verification_checker(llm),
        "service_reasonability": fraud_service_reasonability_checker(llm),
    }
