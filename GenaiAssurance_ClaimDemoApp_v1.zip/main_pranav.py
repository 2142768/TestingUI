import os, json
from dotenv import load_dotenv
from openinference.instrumentation.openai import OpenAIInstrumentor

# from arize.otel import register
# from openinference.instrumentation.langchain import LangChainInstrumentor
import pandas as pd
from pathlib import Path
from collections import defaultdict

import phoenix as px
from phoenix.otel import register
from datetime import datetime, timedelta
from openai import AzureOpenAI

from workflows.Health_workflow import create_health_graph

load_dotenv()

client = AzureOpenAI(
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_deployment=os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
)

# # arize code
# tracer_provider = register(
#     space_id=os.getenv("ARIZE_SPACE_ID"),
#     api_key=os.getenv("ARIZE_API_KEY"),
#     project_name="health-agent-v3",
#     batch=True,
# )


# OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)
# LangChainInstrumentor().instrument(tracer_provider=tracer_provider)

px.launch_app()
print("The Phoenix UI:", px.active_session().url)


# phoenix code
tracer_provider = register(
    project_name=os.environ["phoenix_project_name"],
    # endpoint="https://app.phoenix.arize.com/v1/traces",
    auto_instrument=True,
)
tracer = tracer_provider.get_tracer(__name__)
OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)
# LangChainInstrumentor().instrument(tracer_provider=tracer_provider)

print("project initiated successfully")


if __name__ == "__main__":

    output_dir = Path("output")
    output_dir.mkdir(parents=True, exist_ok=True)

    eval_results = defaultdict(list)

    function_definitions = """
verify_document: Verifies the validity of claim documents. Requires policy_id, document, is_valid_claim, and reason.
check_eligibility: Checks if the claim is eligible based on policy details. Requires policy_id, policy_start, policy_end, and accident_date.
check_fraud: Checks for fraud indicators in the claim. Requires policy_id, document, claim_amount, and estimated_damage_cost.
generate_summary: Generates a summary of the claim processing results. Requires policy_id, doc_status, eligibility_status, and fraud_status.
make_decision: Makes a final decision on the claim. Requires policy_id, doc_status, eligibility_status, fraud_status, and summary.
"""

    claim_input = {
        "policy_id": "HLT-2001",
        "domain": "Health Insurance (Major Medical Plan)",
        "claim_record": {
            "name": "Valid Medical",
            "policy_id": "HLT-2001",
            "policy_start": "2025-01-01",
            "policy_end": "2025-12-31",
            "claim_type": "Health Insurance (Major Medical Plan)",
            "accident_date": "2025-05-15",
            "claim_amount": 12000,
            "notes": [
                "document_verification_agent - submitted_documents_completeness: All required documents have likely been provided, as inferred from the valid claim status.",
                "document_verification_agent - authenticity_check: Submitted documents are genuine, as inferred from the valid claim status.",
                "document_verification_agent - duplicate_document_check: No duplicate bills or records have been submitted, as inferred from the valid claim status.",
                "document_verification_agent - provider_details_verification: Provider information matches official records, as inferred from the valid claim status.",
                "document_verification_agent - service_date_verification: Service dates on documents align with the claimed event, as inferred from the valid claim status.",
            ],
        },
    }

    input_data = claim_input

    workflow = create_health_graph(claim_input)
    result = workflow.invoke(input_data)

    px_client = px.Client()
    start_time = datetime.now() - timedelta(minutes=5)
    end_time = datetime.now()

    phoenix_df = px_client.query_spans(
        start_time=start_time,
        end_time=end_time,
        project_name=os.environ["phoenix_project_name"],
        limit=100,  # Limit number of spans to 100
        root_spans_only=True,  # Only include root spans
    )
    phoenix_df = phoenix_df[phoenix_df["span_kind"] == "LLM"]
    phoenix_df = phoenix_df[
        ["attributes.llm.input_messages", "attributes.llm.output_messages"]
    ]

    print("run the framework")

    # TOOL_SELECTION_EVAL_TEMPLATE = """
    # You are an evaluator assessing whether the AI selected the correct tool for a step in the insurance claim process.

    # Tool Invoked: {tool_invoked}
    # Available Tools: {available_tools}
    # Step Input: {step_input}
    # Ground Truth Tool: {ground_truth_tool}

    # Was the tool selection appropriate?

    # Respond in JSON:
    # {{
    # "score": <float between 0.0 and 1.0>,
    # "justification": "<brief explanation>",
    # "tool_correct": <true/false>
    # }}
    # """

    # TOOL_CALL_EVAL_TEMPLATE = """
    # You are evaluating the correctness of a tool (agent) call in an insurance claim processing system.

    # Tool Name: {tool_name}
    # Inputs Provided:
    # {tool_inputs}

    # Output Produced:
    # {tool_output}

    # Does the tool have all necessary inputs to perform its task? Was the output consistent with those inputs and the tool's role?

    # Respond in JSON:
    # {{
    # "score": <0.0 to 1.0>,
    # "input_completeness": "<brief comment>",
    # "output_validity": "<brief comment>",
    # "tool_call_correct": <true/false>
    # }}
    # """

    from opentelemetry import trace

    # from opentelemetry.sdk.trace.export import BatchSpanProcessor
    # from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

    # # Configure OTLP exporter for Phoenix (Arize)
    # otlp_exporter = OTLPSpanExporter(
    #     endpoint="YOUR_PHOENIX_OTLP_ENDPOINT",  # e.g., https://api.arize.com/otlp/v1/traces
    #     headers={"Authorization": "Bearer YOUR_PHOENIX_API_KEY"}  # Replace with your API key or token
    # )
    # span_processor = BatchSpanProcessor(otlp_exporter)
    # trace.get_tracer_provider().add_span_processor(span_processor)

    # Extract and infer fields
    decision = result.get("decision", "approved")
    reason = result.get(
        "reason",
        "Document verification passed: All rules were either explicitly validated in the notes or compliance was inferred based on provided claim details.",
    )
    summary = "All required documents were provided, genuine, non-duplicate, with verified provider details and service dates, leading to claim approval."  # Inferred
    reflection = "No explicit reflection provided; inferred that agent reviewed document verification notes."  # Inferred
    input_data = json.dumps(
        result.get("claim_record", {})
    )  # Using claim_record as input
    output = json.dumps(
        result.get("decision_result", {})
    )  # Using decision_result as output
    final_summary = summary  # Same as summary for consistency
    agent_results = (
        result.get("document_check_result", "")
        + "\n"
        + json.dumps(result.get("decision_result", {}))
    )  # Concatenated results
    policy_id = result.get("policy_id", "unknown")

    # Evaluation templates
    EVAL_TEMPLATES = {
        "decision_eval": """
    You are evaluating the final decision made by an AI agent for a claim.

    Decision: {decision}
    Reason: {decision_reason}
    Summary: {summary}

    Was this decision justified?

    Respond in JSON:
    {{
    "score": <0.0 to 1.0>,
    "decision_justified": <true/false>,
    "justification": "<explanation>"
    }}
    """,
        "reflection_eval": """
    Evaluate the quality of this agent's self-reflection.

    Reflection: {reflection}
    Input: {input}
    Output: {output}

    Was the reflection thoughtful and accurate?

    Respond in JSON:
    {{
    "score": <0.0 to 1.0>,
    "reflection_quality": "<brief comment>",
    "reflection_valid": <true/false>
    }}
    """,
        "final_call_eval": """
    You are reviewing the overall insurance claim workflow.

    Final Summary: {final_summary}
    Agent Results: {agent_results}

    Was the process consistent and complete?

    Respond in JSON:
    {{
    "overall_score": <0.0 to 1.0>,
    "consistent": <true/false>,
    "comment": "<brief final assessment>"
    }}
    """,
    }

    # Function to evaluate a prompt with tracing
    def evaluate_prompt(template_key, **kwargs):

        with tracer.start_as_current_span(name=f"eval::{template_key}") as span:

            span.set_attribute("evaluation.template", template_key)
            span.set_attribute("claim.policy_id", kwargs.get("task", policy_id))

            prompt = EVAL_TEMPLATES[template_key].format(**kwargs)
            try:
                response = client.chat.completions.create(
                    model="gpt-4o",  # Replace with your deployed model name
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.0,
                    max_tokens=256,
                )
                result = json.loads(
                    response.choices[0]
                    .message.content.strip()
                    .replace("```json", "")
                    .replace("```", "")
                )
                span.set_attribute("evaluation.result", json.dumps(result))
                return result

            except Exception as e:

                span.record_exception(e)
                span.set_status(
                    trace.Status(trace.StatusCode.ERROR, description=str(e))
                )
                return {"error": f"API call failed: {str(e)}"}

    # Run evaluations with tracing
    results = {
        "decision_evaluation": evaluate_prompt(
            "decision_eval",
            decision=decision,
            decision_reason=reason,
            summary=summary,
            task=policy_id,
        ),
        "reflection_evaluation": evaluate_prompt(
            "reflection_eval",
            reflection=reflection,
            input=input_data,
            output=output,
            task=policy_id,
        ),
        "final_call_evaluation": evaluate_prompt(
            "final_call_eval",
            final_summary=final_summary,
            agent_results=agent_results,
            task=policy_id,
        ),
    }

    # Print results
    print(json.dumps(results, indent=2))

    # Ensure traces are exported
    # trace.get_tracer_provider().force_flush()

    print("Finished")
