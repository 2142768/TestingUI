from langchain_core.runnables import Runnable
from langchain_core.messages import HumanMessage
from langchain_community.chat_models import AzureChatOpenAI
import os
from dotenv import load_dotenv

load_dotenv()

llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0.2,
    max_tokens=500,
    model="GPT4o",
)


from langchain.schema import HumanMessage


class ClaimClassifierAgent:
    def __init__(self, llm):
        self.llm = llm

    def classify(self, input: dict) -> str:
        prompt = f"""
        You are a classification agent. 
        Given the following insurance claim details, identify the appropriate claim category.

        Claim Details:
        Type: {input.get("claim_type")}
        Description: {input.get("claim_details", "")}

        Respond with one of: 'Auto_Insurance', 'health', or 'base'
        """

        response = self.llm.invoke([HumanMessage(content=prompt)])
        classification = response.content.strip().lower()

        # Optional validation fallback
        if classification not in ["Auto_Insurance", "health", "base"]:
            classification = "base"

        return classification
