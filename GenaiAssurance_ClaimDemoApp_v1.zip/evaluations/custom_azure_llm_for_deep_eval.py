import json
from types import SimpleNamespace
from pydantic import BaseModel
from typing import Any
from deepeval.metrics.g_eval.g_eval import GEval as GEvalClass
from deepeval.metrics.conversational_g_eval.conversational_g_eval import (
    ConversationalGEval as ConvGEvalClass,
)

from deepeval.models.base_model import DeepEvalBaseLLM
from langchain.schema import HumanMessage

HumanMessage.__iter__ = lambda self: iter([self])


def dict_to_namespace(obj):
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: dict_to_namespace(v) for k, v in obj.items()})
    elif isinstance(obj, list):
        return [dict_to_namespace(item) for item in obj]
    else:
        return obj


class LandmarkResponseSchema(BaseModel):
    description: str


class ReasonScore(BaseModel):
    score: float
    reason: str


class CustomAzureLLM(DeepEvalBaseLLM):
    def __init__(self, model):
        super().__init__(model_name="Custom Azure OpenAI Model", model=model)

    def load_model(self, model):
        return model

    def _extract_prompt_text(self, prompt):
        return prompt if isinstance(prompt, str) else str(prompt)

    def _handle_schema_output(self, output_text: str, schema, **kwargs) -> Any:
        try:
            data = json.loads(output_text)
            name = getattr(schema, "__name__", "")

            if name == "Knowledge":
                if isinstance(data, dict) and "data" not in data:
                    data = {"data": data}
                return dict_to_namespace(data)

            elif name in ["KnowledgeRetentionVerdict", "ConversationRelevancyVerdict"]:
                if isinstance(data, str):
                    return SimpleNamespace(verdict=data)
                elif isinstance(data, dict):
                    return dict_to_namespace(data)
                else:
                    return SimpleNamespace(verdict="")

            elif name == "OutOfCharacterResponseVerdicts":
                if isinstance(data, dict) and "verdicts" not in data:
                    data["verdicts"] = []
                elif not isinstance(data, dict):
                    data = {"verdicts": []}
                return dict_to_namespace(data)

            elif name == "GoalAndOutcome":
                data_ns = dict_to_namespace(data)
                if not hasattr(data_ns, "user_goal"):
                    setattr(data_ns, "user_goal", "")
                if not hasattr(data_ns, "task_outcome"):
                    setattr(data_ns, "task_outcome", "")
                return data_ns

            elif name == "UserIntentions":
                if isinstance(data, dict) and "intentions" not in data:
                    data["intentions"] = []
                elif not isinstance(data, dict):
                    data = {"intentions": []}
                return dict_to_namespace(data)

            elif name == "AssessmentAnswer":
                expected_len = kwargs.get("expected_answers_len", 3)
                if isinstance(data, dict):
                    answers = data.get("answers", [])
                    if not isinstance(answers, list):
                        answers = ["yes"] * expected_len
                    while len(answers) < expected_len:
                        answers.append("yes")
                    data["answers"] = answers[:expected_len]
                else:
                    data = {"answers": ["yes"] * expected_len}
                return dict_to_namespace(data)

            else:
                key = name.lower() if name else "statements"
                if isinstance(data, dict) and key not in data:
                    data[key] = []
                elif not isinstance(data, dict):
                    data = {key: []}
                return dict_to_namespace(data)

        except Exception:
            name = getattr(schema, "__name__", "")
            if name == "Knowledge":
                return SimpleNamespace(data="")
            elif name in ["KnowledgeRetentionVerdict", "ConversationRelevancyVerdict"]:
                return SimpleNamespace(verdict="yes")
            elif name == "OutOfCharacterResponseVerdicts":
                return SimpleNamespace(verdicts=[])
            elif name == "GoalAndOutcome":
                return SimpleNamespace(user_goal="", task_outcome="", reason="")
            elif name == "UserIntentions":
                return SimpleNamespace(intentions=[])
            elif name == "AssessmentAnswer":
                return SimpleNamespace(answers=["yes", "yes", "yes"])
            else:
                key = name.lower() if name else "statements"
                return SimpleNamespace(**{key: [], "reason": ""})

    def generate(self, prompt: str, **kwargs):
        schema = kwargs.pop("schema", None)
        expected_answers_len = kwargs.get("expected_answers_len", 3)
        message = HumanMessage(content=self._extract_prompt_text(prompt))
        res = self.model.generate([message], **kwargs)
        output_text = res.generations[0][0].text.strip()
        return (
            self._handle_schema_output(
                output_text, schema, expected_answers_len=expected_answers_len
            )
            if schema
            else output_text
        )

    async def a_generate(self, prompt: str, **kwargs):
        schema = kwargs.pop("schema", None)
        expected_answers_len = kwargs.get("expected_answers_len", 3)
        message = HumanMessage(content=self._extract_prompt_text(prompt))
        res = await self.model.agenerate([message], **kwargs)
        output_text = res.generations[0][0].text.strip()
        return (
            self._handle_schema_output(
                output_text, schema, expected_answers_len=expected_answers_len
            )
            if schema
            else output_text
        )

    async def a_generate_raw_response(self, prompt: str, **kwargs):
        response_text = await self.a_generate(prompt, **kwargs)
        fake_result = SimpleNamespace(
            generations=[[SimpleNamespace(text=response_text)]], llm_output={}
        )
        return fake_result, 0

    def get_model_name(self, *args, **kwargs):
        return self.model_name


if not hasattr(ConvGEvalClass, "_original_conv_a_evaluate"):
    ConvGEvalClass._original_conv_a_evaluate = ConvGEvalClass._a_evaluate


async def patched_conv_a_evaluate(self, test_case):
    if self.evaluation_cost is None:
        self.evaluation_cost = 0

    try:
        prompt_parts = []
        for param in self.evaluation_params:
            value = getattr(test_case, param.value, None)
            if isinstance(value, list):
                value = "\n".join(value)
            prompt_parts.append(f"{param.name.replace('_', ' ').capitalize()}: {value}")
        prompt = (
            "\n\n".join(prompt_parts)
            + f"\n\nEvaluate the agent based on this criteria: {self.criteria}"
        )

        res = await self.model.a_generate(prompt, schema=ReasonScore)
        print("[DEBUG] ConversationalGEval Raw Response:", res)

        score = res.score

        # --- Post-processing for robustness ---
        if isinstance(score, str):
            if score.strip().lower() in ["yes", "true", "professional"]:
                score = 1.0
            elif score.strip().lower() in ["no", "false", "unprofessional"]:
                score = 0.0
            else:
                try:
                    score = float(score)
                except:
                    score = 0.0
        elif not isinstance(score, (float, int)):
            score = 0.0

        return float(score), str(res.reason)

    except Exception as e:
        output = await self.model.a_generate(prompt)
        return 0.0, str(output)


ConvGEvalClass._a_evaluate = patched_conv_a_evaluate

if not hasattr(GEvalClass, "_original_a_evaluate"):
    GEvalClass._original_a_evaluate = GEvalClass._a_evaluate


async def patched_geval_a_evaluate(self, test_case):
    if self.evaluation_cost is None:
        self.evaluation_cost = 0
    try:
        prompt_parts = []
        for param in self.evaluation_params:
            value = getattr(test_case, param.value, None)
            if isinstance(value, list):
                value = "\n".join(value)
            prompt_parts.append(f"{param.name.replace('_', ' ').capitalize()}: {value}")
        prompt = (
            "\n\n".join(prompt_parts)
            + f"\n\nEvaluate the agent based on this criteria: {self.criteria}"
        )

        res = await self.model.a_generate(prompt, schema=ReasonScore)
        print("[DEBUG] GEval Raw Response:", res)

        score = res.score

        # --- Post-processing for robustness ---
        if isinstance(score, str):
            if score.strip().lower() in ["yes", "true", "correct"]:
                score = 1.0
            elif score.strip().lower() in ["no", "false", "incorrect"]:
                score = 0.0
            else:
                try:
                    score = float(score)
                except:
                    score = 0.0
        elif not isinstance(score, (float, int)):
            score = 0.0

        return float(score), str(res.reason)

    except Exception as e:
        output = await self.model.a_generate(prompt)
        return 0.0, str(output)


GEvalClass._a_evaluate = patched_geval_a_evaluate
