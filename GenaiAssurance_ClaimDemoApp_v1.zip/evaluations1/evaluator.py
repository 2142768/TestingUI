import json
import uuid

import pandas as pd
from typing import Dict, List
from datetime import datetime
from langchain_core.messages import HumanMessage

from evaluations1.prompts import TOOL_CALL_EVAL_TEMPLATE
from evaluations1.agent_config import generate_tool_eval_prompt

from arize.pandas.logger import Client

# Initialize the Arize client (replace with your API Key and Space ID)
arize_client = Client(api_key="YOUR_ARIZE_API_KEY", space_key="YOUR_ARIZE_SPACE_KEY")


def run_dynamic_evaluations(final_state: Dict, llm) -> List[Dict]:
    """
    Iterates over tool outputs in the final_state,
    generates evaluation prompts using agent_config,
    and runs them through the LLM.
    """
    results = []

    for key, output in final_state.items():
        # Only evaluate structured outputs from tools/agents
        if not isinstance(output, (dict, list)):
            continue

        # Try to generate a tool evaluation prompt
        prompt = generate_tool_eval_prompt(
            tool_result_key=key, tool_inputs=final_state, tool_output=output
        )

        if prompt:
            try:
                response = llm.invoke([HumanMessage(content=prompt)])
                eval_result = json.loads(response.content)

                results.append(
                    {
                        "timestamp": datetime.utcnow().isoformat(),
                        "step": key,
                        "tool": key,
                        "score": eval_result.get("score", 0.0),
                        "justification": eval_result.get("justification", ""),
                        "tool_call_correct": eval_result.get(
                            "tool_call_correct", False
                        ),
                        "input_completeness": eval_result.get("input_completeness", ""),
                        "output_validity": eval_result.get("output_validity", ""),
                        "raw_llm_response": response.content,
                    }
                )

            except Exception as e:
                results.append(
                    {
                        "timestamp": datetime.utcnow().isoformat(),
                        "step": key,
                        "tool": key,
                        "score": 0.0,
                        "tool_call_correct": False,
                        "justification": f"Evaluation failed: {str(e)}",
                        "raw_llm_response": "ERROR",
                    }
                )

    return results


# Upload results to Arize
def batch_log_evaluations_to_arize(
    evaluations: list[dict], project_name: str, dataset_name: str
):
    if not evaluations:
        return
    arize = Client(
        space_key="your_space_key", api_key="your_api_key"
    )  # Replace credentials

    df = pd.DataFrame(
        [
            {
                "evaluation_id": str(uuid.uuid4()),
                "timestamp": e["timestamp"],
                "eval_type": e.get("eval_type", ""),
                "tool_name": e.get("tool_name", ""),
                "score": e.get("score"),
                "decision_correct": e.get("decision_correct", ""),
                "reasoning_valid": e.get("reasoning_valid", ""),
                "justification": e.get("justification", ""),
                "raw_llm_response": e.get("raw_llm_response", "")[:500],
            }
            for e in evaluations
        ]
    )
    arize.log_dataframe(
        df, dataset_name=dataset_name, project_name=project_name, sync=True
    )
