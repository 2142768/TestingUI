from datetime import datetime
from typing import Dict, Any
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import HumanMessage
import json
from configuration.logger import log_trace
from configuration.state import GraphState


def eligibility_checker_agent(llm) -> RunnableLambda:
    def run(state: GraphState) -> Dict[str, Any]:
        state_data = state.dict()  # type: ignore
        claim_record = state_data.get("claim_record", {})
        rules = state_data.get("rules", [])
        policy_id = claim_record.get("policy_id", "UNKNOWN")
        claim_id = f"CLM_{policy_id}"

        prompt = f"""
You are an AI assistant tasked with validating an insurance claim for the eligibility_checker_agent based on provided claim details and predefined rules.

You will receive:
1. A claim record with fields: `name`, `policy_id`, `policy_start`, `policy_end`, `claim_type`, `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
2. Provided Rules for the eligibility_checker_agent for the claim type 'Health Insurance (Major Medical Plan)'.

Your task is to:
- Validate the claim record against the provided rules for the eligibility_checker_agent.
- Check the `notes` for explicit rule validations (e.g., "eligibility_checker_agent: description").
- For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields (e.g., check `accident_date` against `policy_start` and `policy_end`).
- If any rule fails, the agent's status is "failed". All rules must pass for the status to be "passed".
- Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
  - Use 0.9 for rules explicitly validated in notes.
  - Use 0.6–0.8 for inferred validations based on fields.
  - Use 0.4–0.5 for rules requiring external data with no explicit note.

Output STRICTLY a JSON result with a single entry for the eligibility_checker_agent:
- `timestamp`: Use current UTC timestamp
- `claim_id`: "CLM_{policy_id}"
- `step`: "eligibility_checker_agent"
- `status`: "<passed/failed>"
- `reason`: "<explanation>"
- `confidence_score`: <float>

**Input Data:**

Claim Record:
{json.dumps(claim_record, indent=2)}

Rules for eligibility_checker_agent (Claim Type 'Health Insurance (Major Medical Plan)'):
{json.dumps(rules, indent=2)}
        """

        response = llm.invoke([HumanMessage(content=prompt)])
        print("Eligibility response:", response.content)
        try:
            response_content = (
                response.content.strip().replace("```json", "").replace("```", "")
            )
            parsed = json.loads(response_content)
            print(f"Eligibility LLM Response: {parsed}")  # Debugging line
            # if (
            #     not isinstance(parsed, list)
            #     or not parsed
            #     or not isinstance(parsed[0], dict)
            # ):
            #     raise ValueError(
            #         "Invalid LLM output: Expected a list with a dictionary"
            #     )
        except (json.JSONDecodeError, ValueError) as e:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "eligibility_checker_agent",
                    "status": "failed",
                    "reason": f"Unable to parse LLM output: {str(e)}",
                    "confidence_score": 0.0,
                }
            ]

        # parsed[0]["raw_llm_response"] = response.content
        log_trace(claim_id=claim_id, step="eligibility_checker_agent", output=parsed)
        return {"eligibility_check_result": parsed, "input": state_data}

    return RunnableLambda(run)
