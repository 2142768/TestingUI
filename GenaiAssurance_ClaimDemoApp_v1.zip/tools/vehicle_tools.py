from langchain.tools import tool
import requests
import random


# ------------------------------
# TOOL 1: Verify Vehicle VIN
# ------------------------------
@tool
def verify_vehicle_vin(vin: str) -> str:
    """
    Simulates verification of a vehicle VIN against a vehicle registry.
    """
    if vin and len(vin) == 17:
        if vin.startswith("1HG"):
            return "VIN verified successfully."
        return "VIN not found in registry."
    return "Invalid VIN format."


# ----------------------------------
# TOOL 2: Lookup Prior Vehicle Claims
# ----------------------------------
@tool
def lookup_previous_vehicle_claims(vin: str, accident_date: str) -> str:
    """
    Simulates checking if the same vehicle had a prior similar claim.
    """
    if hash(vin + accident_date) % 4 == 0:
        return "Duplicate claim detected for similar accident."
    return "No duplicate claims found."


# -----------------------------------
# TOOL 3: Check Repair Cost Estimate
# -----------------------------------
@tool
def check_repair_cost_estimate(damage_type: str, claim_amount: float) -> str:
    """
    Simulates comparing the claimed repair cost against standard rates.
    """
    benchmark_table = {
        "front_bumper": 5000,
        "side_door": 3000,
        "windshield": 1500,
        "engine": 10000,
    }
    benchmark = benchmark_table.get(damage_type, 4000)
    if claim_amount > benchmark * 1.2:
        return (
            f"Claim amount {claim_amount} exceeds benchmark ({benchmark}) by over 20%."
        )
    elif claim_amount < benchmark * 0.8:
        return f"Claim amount {claim_amount} is significantly under benchmark ({benchmark})."
    return f"Claim amount {claim_amount} is within acceptable range for {damage_type}."


# ---------------------------------------
# TOOL 4: Validate Police Report Access
# ---------------------------------------
@tool
def validate_police_report_url(report_url: str) -> str:
    """
    Checks if the police report file is accessible online.
    """
    try:
        response = requests.head(report_url, timeout=5)
        if response.status_code == 200:
            return "Police report is accessible."
        return f"Report URL responded with status code: {response.status_code}"
    except Exception as e:
        return f"Failed to access police report: {str(e)}"
