from dotenv import load_dotenv
import os, json, re
from openinference.instrumentation.openai import OpenAIInstrumentor
from arize.otel import register
from openinference.instrumentation.langchain import LangChainInstrumentor
import pandas as pd
from pathlib import Path
from collections import defaultdict

load_dotenv()
ARIZE_API_KEY = os.environ["ARIZE_API_KEY"]

from datetime import datetime
from arize.exporter import ArizeExportClient
from arize.utils.types import Environments


tracer_provider = register(
    space_id=os.getenv("ARIZE_SPACE_ID"),
    api_key=os.getenv("ARIZE_API_KEY"),
    project_name="health-agent-v3",
    batch=True,
)

OpenAIInstrumentor().instrument(tracer_provider=tracer_provider)
LangChainInstrumentor().instrument(tracer_provider=tracer_provider)

# Exporting your dataset into a dataframe
client = ArizeExportClient()
# primary_df = client.export_model_to_df(
#     space_id=os.environ["ARIZE_SPACE_ID"],  # this will be prefilled by export
#     model_id=os.environ["MODEL_ID"],  # this will be prefilled by export
#     environment=Environments.TRACING,
#     start_time=datetime.fromisoformat(""),  # this will be prefilled by export
#     end_time=datetime.fromisoformat(""),  # this will be prefilled by export
# )


# import os
# from phoenix.evals import OpenAIModel, llm_classify

# api_key = os.environ.get("AZURE_OPENAI_API_KEY")
# eval_model = OpenAIModel(model="gpt-4o", temperature=0, api_key=api_key)

# MY_CUSTOM_TEMPLATE = """
#     You are evaluating the positivity or negativity of the responses to questions.
#     [BEGIN DATA]
#     ************
#     [Question]: {input}
#     ************
#     [Response]: {output}
#     [END DATA]


#     Please focus on the tone of the response.
#     Your answer must be single word, either "positive" or "negative"
#     """


# primary_df["input"] = primary_df["attributes.input.value"]
# primary_df["output"] = primary_df["attributes.output.value"]


# evals_df = llm_classify(
#     dataframe=primary_df,
#     template=MY_CUSTOM_TEMPLATE,
#     model=eval_model,
#     rails=["positive", "negative"],
# )

from openinference.instrumentation.helpers import get_span_id
from opentelemetry.trace import get_current_span

# ... within a context where a span is active
span = get_current_span()
span_id = get_span_id(span)
print(f"Current Span ID: {span_id}")

from opentelemetry import trace

tracer = trace.get_tracer(__name__)
with tracer.start_as_current_span("my-operation") as span:
    span_id = span.context.span_id.to_bytes(8, "big").hex()  # Convert to hex string
    print(f"Span ID for 'my-operation': {span_id}")

evaluation_data = {
    "context.span_id": ["74bdfb83-a40e-4351-9f41-19349e272ae9"],  # Use your span_id
    "eval.myeval.label": ["accuracy"],  # Example label name
    "eval.myeval.score": [0.95],  # Example label value
    "eval.myeval.explanation": ["some explanation"],
}
evaluation_df = pd.DataFrame(evaluation_data)


import os
from arize.pandas.logger import Client

API_KEY = os.environ.get("ARIZE_API_KEY")
SPACE_ID = os.environ.get("ARIZE_SPACE_ID")
DEVELOPER_KEY = os.environ.get("ARIZE_DEVELOPER_KEY")

# Initialize Arize client using the model_id and version you used previously
arize_client = Client(space_id=SPACE_ID, api_key=API_KEY, developer_key=DEVELOPER_KEY)

# Set the evals_df to have the correct span ID to log it to Arize
evals_df = evals_df.set_index(primary_df["context.span_id"])

# send the eval to Arize
arize_client.log_evaluations_sync(evals_df, "YOUR_PROJECT_NAME")
