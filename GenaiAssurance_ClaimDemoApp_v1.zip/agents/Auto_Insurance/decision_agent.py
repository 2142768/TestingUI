from supervisor.supervisor_agent import *
from configuration.logger import log_trace
from agents.Auto_Insurance.fraud_checker_agent import *
from configuration.state import GraphState
import re
from langchain.schema import HumanMessage


# def decision_maker_agent(self, state: GraphState) -> dict:
#     # thresholds
#     HIGH_FRAUD_THRESHOLD = 0.7
#     MEDIUM_FRAUD_THRESHOLD = 0.4
#
#     doc_ok = state.doc_status == "approved"
#     fraud_score = state.fraud_score or 1.0
#
#     if not doc_ok:
#         decision, reason = "rejected", "Document verification failed."
#     elif fraud_score <= MEDIUM_FRAUD_THRESHOLD:
#         decision, reason = "approved", "Documents valid and fraud risk low/medium."
#     else:
#         decision, reason = "rejected", "High fraud risk."
#
#     confidence = round(1.0 - fraud_score, 2)  # or some mapping you prefer
#
#     log_trace(
#         claim_id=state.claim_id or f"CLM_{state.policy_id}",
#         step="decision_agent",
#         output={"decision": decision, "reason": reason, "confidence": confidence},
#     )
#
#     return {"decision": decision, "reason": reason, "confidence": confidence}

from typing import Dict, Any
from configuration.state import GraphState
from configuration.logger import log_trace


def decision_maker_agent(state: GraphState) -> Dict[str, Any]:
    # HIGH_FRAUD_THRESHOLD = 0.7
    # MEDIUM_FRAUD_THRESHOLD = 0.4

    doc_ok = state.document_check_result.get("document_check_status") == "approved"
    fraud_score = state.fraud_score
    print(f"Fraud score: {fraud_score}")
    reason = state.summary or ""
    amount = state.claim_record.get(
        "claim_amount", 0.0
    )  # Assuming claim_amount is the final amount to be paid
    if not doc_ok:
        decision, reason, final_amount = (
            "rejected",
            reason if reason else "Document verification failed.",
            0.0,
        )
    elif fraud_score == 0.0:
        decision, reason, final_amount = "approved", reason, amount
    else:
        decision, reason, final_amount = "rejected", reason, 0.0

    output = {
        "decision": decision,
        "reason": reason,
        "final_amount": final_amount,
        "confidence_score": 0.9,  # Assuming a default confidence score
    }
    log_trace(
        claim_id=state.claim_id or f"CLM_{state.policy_id}",
        step="decision_maker_agent",
        output=output,
    )
    return output
