import json

from typing import Dict
from langchain_core.runnables import Runnable


def decision_agent() -> Runnable:
    """
    Decision agent that makes a final determination on the insurance claim based on the document verification result.
    """

    def run_agent(state: Dict) -> Dict:
        # Extract document verification result from state
        # doc_result = state.get("document_check_result", {})
        doc_result = json.loads(state.get("document_check_result"))
        doc_status = doc_result.get("status", "failed") if doc_result else "failed"
        claim_id = (
            doc_result.get("claim_id", state.get("policy_id", "unknown"))
            if doc_result
            else state.get("policy_id", "unknown")
        )
        doc_reason = (
            doc_result.get("reason", "Document verification status unclear")
            if doc_result
            else "Document verification status unclear"
        )
        doc_confidence = doc_result.get("confidence", 0.5) if doc_result else 0.5

        # Determine decision based on document verification status
        if doc_status == "passed":
            decision = "approved"
            reason = f"Document verification passed: {doc_reason}"
            confidence = doc_confidence
        else:
            decision = "rejected"
            reason = f"Document verification failed: {doc_reason}"
            confidence = doc_confidence

        # Construct decision result
        decision_result = {
            "timestamp": "2025-06-26T16:45:00",
            "claim_id": claim_id,
            "step": "decision_agent",
            "decision": decision,
            "reason": reason,
            "confidence": confidence,
        }

        # Update state with decision result
        return {
            "decision_result": decision_result,
            "decision": decision,
            "reason": reason,
            "input": state,
        }

    return run_agent
