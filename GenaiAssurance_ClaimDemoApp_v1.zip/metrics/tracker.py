import json
import os
from datetime import datetime

LOG_DIR = "logs"
os.makedirs(LOG_DIR, exist_ok=True)


# def log_trace(claim_id: str, step: str, data: dict):
#     timestamp = datetime.utcnow().isoformat()
#     log_entry = {
#         "timestamp": timestamp,
#         "claim_id": claim_id,
#         "step": step,
#         "data": data,
#     }
#
#     log_path = os.path.join(LOG_DIR, f"{claim_id}.jsonl")
#     with open(log_path, "a", encoding="utf-8") as f:
#         f.write(json.dumps(log_entry) + "\n")
#     print(f"Logged {step} step for claim {claim_id}")
