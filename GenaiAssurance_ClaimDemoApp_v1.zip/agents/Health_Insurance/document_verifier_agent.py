from datetime import datetime
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import HumanMessage
import json
from configuration.logger import log_trace
from configuration.state import GraphState


def document_verifier_agent(llm) -> RunnableLambda:
    def run(state: GraphState):
        state_data = state.dict()  # type: ignore
        claim_record = state_data.get("claim_record") or {}
        rules = state_data.get("rules", [])
        policy_id = claim_record.get("policy_id", state.policy_id)
        claim_id = f"CLM_{policy_id}"
        is_valid_claim = state_data.get("is_valid_claim", False)
        reason = state_data.get("reason", "")

        log_trace(
            claim_id,
            "document_verifier_agent_input",
            {
                "state": state_data,
                "is_valid_claim": is_valid_claim,
                "rules": rules,
                "reason": reason,
            },
        )

        # Validate claim_record completeness
        required_fields = [
            "name",
            "policy_id",
            "policy_start",
            "policy_end",
            "claim_type",
            "accident_date",
            "claim_amount",
        ]
        missing_fields = [
            field for field in required_fields if not claim_record.get(field)
        ]
        if missing_fields or not claim_record:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "status": "failed",
                    "reason": f"Incomplete claim record: missing {', '.join(missing_fields) if missing_fields else 'claim_record'}",
                    "confidence_score": 0.0,
                }
            ]
            log_trace(claim_id, "document_verifier_agent", {"output": parsed[0]})
            return {"document_verification_result": parsed, "input": state_data}

        if is_valid_claim:
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "status": "passed",
                    "reason": reason or "Claim validated based on input data=True.",
                    "confidence_score": 0.9,
                }
            ]
            log_trace(claim_id, "document_verifier_agent", {"output": parsed[0]})
            return {"document_verification_result": parsed, "input": state_data}

        # Construct prompt for LLM
        prompt = f"""
You are an AI assistant tasked with validating an insurance claim for the document_verification_agent based on provided claim details and predefined rules.

You will receive:
1. A claim record with fields: `name`, `policy_id`, `policy_start`, `policy_end`, `claim_type`, `accident_date`, `claim_amount`, and `notes` (a list of strings indicating rule validations or inferences).
2. Provided Rules for the document_verification_agent for the claim type 'Health Insurance (Major Medical Plan)'.

Your task is to:
- Validate the claim record against the provided rules for the document_verification_agent.
- Check the `notes` for explicit rule validations (e.g., "document_verification_agent: description").
- For rules not explicitly mentioned in `notes`, infer compliance based on the claim fields (e.g., check `accident_date` against `policy_start` and `policy_end`).
- If any rule fails, the agent's status is "failed". All rules must pass for the status to be "passed".
- Assign a confidence score (between 0.0 and 1.0) based on the strength of the evidence or inference:
  - Use 0.9 for rules explicitly validated in notes.
  - Use 0.6–0.8 for inferred validations based on fields.
  - Use 0.4–0.5 for rules requiring external data with no explicit note.

Output STRICTLY a JSON result with a single entry for the document_verification_agent:
- `timestamp`: Use current UTC timestamp
- `claim_id`: "CLM_{policy_id}"
- `step`: "document_verification_agent"
- `status`: "<passed/failed>"
- `reason`: "<explanation>"
- `confidence_score`: <float>

**Input Data:**

Claim Record:
{json.dumps(claim_record, indent=2)}

Rules for document_verification_agent (Claim Type 'Health Insurance (Major Medical Plan)'):
{json.dumps(rules, indent=2)}
        """

        response = llm.invoke([HumanMessage(content=prompt)])
        print(f"document LLM Response: {response.content}")  # Debugging line
        try:
            response_content = (
                response.content.strip().replace("```json", "").replace("```", "")
            )
            parsed = json.loads(response_content)
            print(f"Document parsed: {parsed}")  # Debugging line
            if (
                not isinstance(parsed, list)
                or not parsed
                or not isinstance(parsed[0], dict)
            ):
                raise ValueError(
                    "Invalid LLM output: Expected a list with a dictionary"
                )
        except (json.JSONDecodeError, ValueError) as e:
            log_trace(
                claim_id,
                "document_verifier_agent_error",
                {"error": str(e), "raw_response": response.content, "prompt": prompt},
            )
            parsed = [
                {
                    "timestamp": datetime.utcnow().isoformat(),
                    "claim_id": claim_id,
                    "step": "document_verifier_agent",
                    "status": "failed",
                    "reason": f"Unable to parse LLM output: {str(e)}",
                    "confidence_score": 0.0,
                }
            ]

        parsed[0]["raw_llm_response"] = response.content

        log_trace(claim_id=claim_id, step="document_verifier_agent", output=parsed[0])
        return {"document_verification_result": parsed, "input": state_data}

    return RunnableLambda(run)
